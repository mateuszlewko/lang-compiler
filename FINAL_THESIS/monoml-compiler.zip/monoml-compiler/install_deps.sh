opam update
opam install jbuilder sedlex batteries core llvm menhir ppx_deriving ounit logs
